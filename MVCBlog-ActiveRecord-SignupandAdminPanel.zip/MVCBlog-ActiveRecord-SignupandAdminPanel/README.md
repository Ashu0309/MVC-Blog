# framework
How To Use
1. set site url or any global variable at src/private/config/settings.php
like
$settings['myvar'] = 'myvalue';

2. create Controller based on Sample Controller at src/private/controllers/
3. create View based on Sample View at src/private/views