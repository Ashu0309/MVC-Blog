<?php
session_start();
require_once(dirname(__FILE__) . '/../private/init.php');
