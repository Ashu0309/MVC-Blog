<?php
use App\Libraries\Core;

require_once(dirname(__FILE__).'/config/variables.php');
require_once(dirname(__FILE__).'/config/settings.php');
require_once(dirname(__FILE__).'/libraries/Controller.php');
require_once(dirname(__FILE__).'/libraries/Core.php');

$core = new Core();
