<?php
/**
 * global settings like siteurl, asset url etc
 */
    global $settings;

    $settings = array();

    $settings['siteurl'] = 'http://localhost:8080/public';
