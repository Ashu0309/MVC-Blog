<?php
    define('APPPATH', dirname(dirname(__FILE__)));
