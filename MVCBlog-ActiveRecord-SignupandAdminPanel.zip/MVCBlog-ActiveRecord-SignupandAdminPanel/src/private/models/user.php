<?php

namespace App\Models;

class user extends \ActiveRecord\Model
{
    
}