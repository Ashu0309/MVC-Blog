<?php

namespace App\Models;

class blogtable extends \ActiveRecord\Model
{
    
}