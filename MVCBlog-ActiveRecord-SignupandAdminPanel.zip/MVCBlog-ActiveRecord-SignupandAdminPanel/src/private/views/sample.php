<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome To Framework</title>
    <style>
        #intro {
            border: 1px solid palevioletred;            
        }
        #intro p{
            color: palevioletred;
        }
    </style>
</head>
<body>
    <h1>Welcome To Framework</h1>
    <div id="intro">
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis repellat fuga reprehenderit itaque vitae id necessitatibus quisquam eos facere officia voluptatem esse, labore tempora aut inventore pariatur ad animi qui!
        </p>
    </div>
</body>
</html>